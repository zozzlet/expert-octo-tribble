KORYO TOURS — PUBLIC NEWSLETTER: YEMEN & SOCOTRA (3 TOURS)
============================================================

FILE
  koryo-public-yemen-socotra.html — the full email, ready to paste into
  MailerLite's Custom HTML editor.

BUTTON LINK PLACEHOLDERS (search & replace these 3 strings)
  INSERT_COMBO_TOUR_LINK        — used TWICE: featured combo button + final CTA
  INSERT_MAINLAND_YEMEN_LINK    — Mainland Yemen card button
  INSERT_SOCOTRA_EASTER_LINK    — Socotra Easter card button

  Each one also has a <!-- TODO --> comment right above it in the code.

IMAGES — CLICK TO REPLACE IN MAILERLITE (5 slots + logo)
  All image slots use MailerLite's placeholder image, so in the editor you
  just click each image and swap it from your file manager. The header logo
  is already your hosted Koryo Tours logo.

  1. Koryo Tours logo         already in place — header
  2. Hero                     520 wide — suggested: dragon blood trees at sunset
  3. Combo tour               520 wide — suggested: Shibam skyline
  4. Cultural highlights      520 wide — suggested: honey tasting / school visit
  5. Mainland Yemen card      252 wide — suggested: Wadi Doan
  6. Socotra Easter card      252 wide — suggested: Detwah Lagoon

  Each slot has descriptive alt text so you can tell which is which.

STRUCTURE / EMPHASIS
  1. Hero: "Yemen & Socotra — the journeys almost no one has made"
  2. FEATURED (biggest section): Mainland Yemen & Socotra Combo
     23 Jan – 6 Feb · 15 days/14 nights · small group · one-visa routing
  3. Cultural highlights panel (soft yellow): Sidr honey tasting, Hadibo
     school visit + women-run craft centre, coffee in local homes,
     complimentary Yemeni outfit + live music & dance, camel sesame press,
     resin harvesting, fish markets
  4. Two secondary cards: Mainland Yemen — New Year's Eve trip (red
     "New Year's Eve Trip" badge, 25 Dec 2027 – 1 Jan 2028, 8 days, with
     an italic note that dates may shift once flight schedules are
     announced) and Socotra Easter Tour (23–30 March, 8 days)
  5. "Travelling with Koryo Tours" trust panel (visas, safety, tour leader)
  6. Final yellow CTA pushing the combo tour
  7. Footer with {$unsubscribe} (required by MailerLite — leave in place)

SUGGESTED SUBJECT LINES
  - New: Yemen & Socotra — the journey almost no one has made
  - Mud-brick skyscrapers & dragon blood trees: 3 new departures
  Preheader is built in.

DESIGN
  Same system as the VIP email: ~75% white, ~20% yellow (#F5B41F), Koryo
  stripe colours in the bars/dots/card accents; Circular Std headings with
  Karla body; dark mode + mobile single-column supported.

NOTE ON DATES
  No year is stated for the combo (23 Jan – 6 Feb) or Socotra Easter
  (23–30 March), matching the itinerary docs. Add years if you want them
  explicit. Mainland Yemen is dated 25 Dec 2027 – 1 Jan 2028 per the
  finalised NYE itinerary, with a built-in caveat that dates may shift
  once flight schedules are announced.
