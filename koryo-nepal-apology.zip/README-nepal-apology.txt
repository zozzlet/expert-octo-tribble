KORYO TOURS — NEPAL APOLOGY NOTE
==================================

FILE
  koryo-nepal-apology.html — the full email, ready to paste into
  MailerLite's Custom HTML editor. {$unsubscribe} is already in the
  footer (required by MailerLite — leave it in place).

WHAT'S DIFFERENT FROM THE OTHER KORYO EMAILS
  This one is deliberately plain, per your request for "very simple,
  few text": no tour cards, no hero image, no CTA buttons, no image
  placeholders. Just: logo, a short heading, the apology copy, a
  sign-off, and the footer. The Koryo stripe bars top and bottom are
  kept thin and quiet purely as a brand identifier — teal (#3BB8A8) is
  used only as a small accent on the kicker and links, per the Nepal
  branding used elsewhere in this chat. Karla body / Circular Std
  headings, dark mode + mobile support carried over from the other
  templates.

ONE WORDING CHANGE TO REVIEW
  The text you gave me was your reply to one subscriber's email
  ("Many thanks for your email and of course valid concerns..."), but
  you asked for a newsletter to send to everyone it might have
  affected — not a one-to-one reply. So I adapted the opening line
  from a reply into a broadcast-friendly opener:

    Your version: "Many thanks for your email and of course valid
    concerns. The news on Nepal is horrific and as you rightly
    mention, still on-going with much uncertainty."

    This version: "We want to acknowledge the timing of our recent
    newsletter announcing our new Nepal tour, which went out around
    the same time as the flooding in Nepal. The news is horrific, and
    the situation remains ongoing with much uncertainty."

  Everything after that follows your wording closely (light copy-edit
  only — e.g. "So sorry this one came out to you" became "We're so
  sorry this reached you at such a difficult time," to read naturally
  addressed to a general list rather than a single reply). Check the
  body copy against your original before sending in case you'd like
  it closer to verbatim.

SIGN-OFF
  Currently reads "Best, / The Koryo Tours Team" — your original just
  said "Best," with no name. Swap in a real name/signature if you'd
  rather this come from a specific person.

SUBJECT LINE SUGGESTIONS
  - A note about our recent Nepal email
  - Our apologies for the timing of our last newsletter
  Preheader is built in ("A note about the timing of our recent Nepal
  email.").
