KORYO TOURS — VIP NEWSLETTER: MAINLAND YEMEN & SOCOTRA
========================================================

FILE
  koryo-vip-yemen-socotra.html  — the full email, ready to paste into MailerLite.

HOW TO USE IN MAILERLITE
  1. Create campaign -> choose "Custom HTML editor" (not drag & drop).
  2. Paste the entire contents of the HTML file.
  3. The unsubscribe link is already wired up with MailerLite's {$unsubscribe}
     variable — MailerLite requires this, so leave it in place.
  4. Send yourself a test before sending to the VIP group.

SUGGESTED SUBJECT LINES
  - VIP first access: Yemen & Socotra — new departure
  - Before anyone else: our new Yemen & Socotra departure
  Preheader is built in: "Mud-brick skyscrapers, dragon blood trees & a
  booking link only you have."

IMAGE PLACEHOLDERS TO REPLACE (5 + logo)
  Replace each dashed placeholder <div> with an <img> tag once the images
  are uploaded to MailerLite's file manager. Recommended sizes (2x for
  retina in brackets):

  1. Koryo Tours logo          160 x 48   (320 x 96)   — header, top left
  2. Hero: Shibam at sunset    520 x 300  (1040 x 600)
  3. Shibam towers             250 x 170  (500 x 340)  — Part One, left
  4. Wadi Doan canyon          250 x 170  (500 x 340)  — Part One, right
  5. Dragon blood trees        250 x 170  (500 x 340)  — Part Two, left
  6. Detwah Lagoon             250 x 170  (500 x 340)  — Part Two, right

  Example replacement:
    <img src="YOUR_UPLOADED_URL" width="520" alt="Shibam skyline at sunset"
         style="width:100%; max-width:520px; height:auto; display:block; border-radius:4px;">

DESIGN NOTES
  - Colour split: ~75% white, ~20% yellow (#F5B41F — date band, both CTAs,
    'good to know' panel), remainder in Koryo stripe colours (red #E2373F,
    teal #3BB8A8, orange #F58220, navy #333A8C, green #2EA24C) used in the
    top/bottom stripe bars, divider and bullet dots.
  - Fonts: Circular Std for headings, Karla for body. Karla is loaded from
    Google Fonts; Circular Std is a licensed font that email clients can't
    load remotely, so the stack falls back Circular Std -> Karla -> Arial.
    (If you have Circular Std hosted as a webfont, add its @font-face to
    the <style> block.)
  - Dark mode: supported via prefers-color-scheme + Outlook.com [data-ogsc]
    overrides. Yellow blocks keep dark text; white areas invert to charcoal.
  - Mobile: single column under 620px, stacked images, full-width buttons.

VIP BOOKING LINK (used on both buttons)
  https://koryogroup.com/non-dprk-booking/16951

DATES SHOWN IN THE EMAIL
  "23 Jan – 6 Feb · 15 Days / 14 Nights" — no year is stated, matching the
  itinerary doc. Add the year in the title/date band if you want it explicit.
