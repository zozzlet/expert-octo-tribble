KORYO TOURS — PUBLIC NEWSLETTER: NEPAL (3 TOURS + BLOGS + GUIDES)
====================================================================

FILE
  koryo-public-nepal.html — the full email, ready to paste into
  MailerLite's Custom HTML editor. {$unsubscribe} is already in the
  footer (required by MailerLite — leave it in place).

TOUR CARDS — REDESIGNED TO MATCH THE REAL WEBSITE TOUR CARDS
  Each of the three Nepal tours is now shown as a full-width card in
  the same visual language as your website's tour cards (mint/teal
  panel, small-caps date kicker, big teal-accented title, a short
  underline rule, description, price/notice line, and a two-button
  row: solid red "BOOK NOW" + outline teal "TOUR DETAILS"). On a
  desktop browser your site shows the photo and text side by side —
  in email that two-column bleed layout doesn't render reliably
  (especially in Outlook) and breaks on small phones, so each card
  puts the image on top, full-width, with the same content block
  underneath. All the card elements from your site are kept; only the
  photo's position changes.

  Card 1 — Nepal Culture & Heritage Discovery Tour (the new tour):
    kicker flags it as new since dates aren't set yet; no price is
    known so the card says "Pricing to be announced — register your
    interest to hear first" instead of a real price line.
  Card 2 — Koryo Bhutan and Nepal Adventure: uses the REAL copy you
    showed me from the site — dates (March 2–18, 2027), the full tour
    title incl. "(Bhutan SDF and Drukair flights from Paro to
    Kathmandu included)", the "night in Guwahati, 9 nights in Bhutan
    and 6 nights in Nepal" line, the intro paragraph, the price
    ("From 5,395 USD per person"), and the apply-by notice with the
    circled "!" icon ("Please apply by 24th January, 2027").
  Card 3 — Nepal Tour (solo): no specific dates/price were available,
    so it reads "See dates and pricing on the tour page" rather than
    guessing a number.

TOUR LINK PLACEHOLDERS (search & replace these 6 strings)
  Each card now has its own Book Now + Tour Details pair, matching the
  real site's two-button pattern:
    INSERT_CULTURE_BOOK_LINK     / INSERT_CULTURE_DETAILS_LINK
    INSERT_BHUTAN_BOOK_LINK      / INSERT_BHUTAN_DETAILS_LINK
    INSERT_SOLO_BOOK_LINK        / INSERT_SOLO_DETAILS_LINK
  The final teal CTA block at the bottom re-uses INSERT_CULTURE_DETAILS_LINK.
  Each placeholder has a <!-- TODO --> comment right above it in the code.
  If Book Now and Tour Details should point to the same URL for a given
  tour, just put the same link in both placeholders.

BLOG & TRAVEL GUIDE LINKS — ALREADY LIVE, NO PLACEHOLDERS (unchanged)
  Featured blog:
    https://koryogroup.com/blog/nepal-cultural-tours
  Two more blogs:
    https://koryogroup.com/blog/dhulikhel-to-namobuddha-hike-a-himalayan-hike-and-a-night-in-a-monastery-with-koryo
    https://koryogroup.com/blog/visiting-nepal-s-newar-villages-nepal-beyond-kathmandu
  Three travel guides (in a "Plan your trip" list):
    https://koryogroup.com/travel-guide/kathmandu-nepal-travel-guide
    https://koryogroup.com/travel-guide/boudhanath-stupa-nepal-travel-guide
    https://koryogroup.com/travel-guide/how-to-get-nepal-visa

IMAGES — CLICK TO REPLACE IN MAILERLITE (11 slots + logo)
  Same system as the other emails: MailerLite's placeholder image, click
  each one in the editor and swap from your file manager. Logo already set.

  1. Koryo Tours logo          already in place — header
  2. Hero                      520 wide — suggested: Boudhanath Stupa
  3. Card 1 (Culture tour)     520 wide — suggested: momo cooking class
  4. Card 2 (Bhutan combo)     520 wide — suggested: monastery architecture
  5. Card 3 (solo Nepal)       520 wide — suggested: Dhulikhel Himalayan views
  6. Featured blog image       520 wide — suggested: matches the blog post
  7. Blog card 2 (hike)        252 wide — suggested: Namobuddha hike
  8. Blog card 3 (villages)    252 wide — suggested: Newar village life

  The 3 travel guides are a text list (no images) — no image slots needed.

STRUCTURE
  1. Hero: "Nepal, Beyond the Trek"
  2. "Our Nepal tours" — three full-width website-style tour cards
     (Culture & Heritage NEW, Bhutan combo with real data, solo Nepal)
  3. "From the Koryo blog" (soft teal panel) — 1 featured blog card +
     2 standard blog cards
  4. "Plan your trip" — 3 travel guides as a linked list
  5. Final teal CTA pushing the new tour's details page
  6. Footer with {$unsubscribe}

SUGGESTED SUBJECT LINES
  - New: Nepal, Beyond the Trek — our cultural adventure tour
  - Momo classes, monastery nights & Everest views: new in Nepal
  Preheader is built in.

DESIGN
  Same system as before: ~75% white, ~20% teal (#3BB8A8, darker #23887C
  for teal text on white), Koryo stripe colours in the bars/dots, red
  (#E2373F) used specifically for the "Book Now" buttons across all
  three cards to match the real site; Circular Std headings with Karla
  body; dark mode + mobile single-column supported (buttons stack full
  width under 620px).
