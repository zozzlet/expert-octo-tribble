KORYO TOURS — PUBLIC NEWSLETTER: NEPAL (3 TOURS + BLOGS + GUIDES)
====================================================================

FILE
  koryo-public-nepal.html — the full email, ready to paste into
  MailerLite's Custom HTML editor. {$unsubscribe} is already in the
  footer (required by MailerLite — leave it in place).

TOUR LINK PLACEHOLDERS (search & replace these 3 strings)
  INSERT_CULTURE_TOUR_LINK   — used TWICE: featured tour button + final CTA
  INSERT_NEPAL_BHUTAN_LINK   — Nepal & Bhutan Combo card button
  INSERT_NEPAL_SOLO_LINK     — Nepal Tour (solo) card button

  Each has a <!-- TODO --> comment right above it in the code.

BLOG & TRAVEL GUIDE LINKS — ALREADY LIVE, NO PLACEHOLDERS
  Featured blog:
    https://koryogroup.com/blog/nepal-cultural-tours
  Two more blogs:
    https://koryogroup.com/blog/dhulikhel-to-namobuddha-hike-a-himalayan-hike-and-a-night-in-a-monastery-with-koryo
    https://koryogroup.com/blog/visiting-nepal-s-newar-villages-nepal-beyond-kathmandu
  Three travel guides (in a "Plan your trip" list):
    https://koryogroup.com/travel-guide/kathmandu-nepal-travel-guide
    https://koryogroup.com/travel-guide/boudhanath-stupa-nepal-travel-guide
    https://koryogroup.com/travel-guide/how-to-get-nepal-visa

IMAGES — CLICK TO REPLACE IN MAILERLITE (9 slots + logo)
  Same system as the other emails: MailerLite's placeholder image, click
  each one in the editor and swap from your file manager. Logo is already
  your hosted Koryo Tours logo.

  1. Koryo Tours logo          already in place — header
  2. Hero                      520 wide — suggested: Boudhanath Stupa
  3. Featured tour image       520 wide — suggested: momo cooking class
  4. Nepal & Bhutan card       252 wide — suggested: Tiger's Nest, Bhutan
  5. Nepal Tour (solo) card    252 wide — suggested: Dhulikhel Himalayan views
  6. Featured blog image       520 wide — suggested: matches the blog post
  7. Blog card 2 (hike)        252 wide — suggested: Namobuddha hike
  8. Blog card 3 (villages)    252 wide — suggested: Newar village life

  The 3 travel guides are a text list (no images) with coloured bullet
  dots and an arrow link — no image slots needed there.

STRUCTURE
  1. Hero: "Nepal, Beyond the Trek" — new cultural tour + 2 existing tours
  2. FEATURED (biggest section): Nepal Culture & Heritage Discovery Tour
     7 days/6 nights · small group · dates announced soon
  3. "Two more ways to travel Nepal" — Koryo-style tour cards for the
     existing Nepal & Bhutan Combo and solo Nepal Tour
  4. "From the Koryo blog" (soft teal panel) — 1 featured blog card
     (bigger, with a "★ Featured read" tag) + 2 standard blog cards
  5. "Plan your trip" — 3 travel guides as a clean linked list
  6. Final teal CTA pushing the new tour
  7. Footer with {$unsubscribe}

SUGGESTED SUBJECT LINES
  - New: Nepal, Beyond the Trek — our cultural adventure tour
  - Momo classes, monastery nights & Everest views: new in Nepal
  Preheader is built in.

DESIGN
  Same system as the Nepal VIP email: ~75% white, ~20% teal (#3BB8A8,
  darker #23887C for teal text on white), Koryo stripe colours in the
  bars/dots/card accents (indigo accent on the Bhutan combo card, orange
  accent on the solo Nepal card); Circular Std headings with Karla body;
  dark mode + mobile single-column supported.

NOTE ON DATES / DISCOUNT
  No VIP discount or early-access language in this version — it's the
  public announcement, so it reads as a straightforward new-tour launch.
  Dates for the new tour are shown as "Dates announced soon" per the
  itinerary doc; update once confirmed.
