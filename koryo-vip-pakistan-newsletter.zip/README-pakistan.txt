KORYO TOURS — VIP NEWSLETTER: PAKISTAN RESEARCH TRIP 2027
==========================================================

FILE
  koryo-vip-pakistan.html — the full email, ready to paste into
  MailerLite's Custom HTML editor. The {$unsubscribe} link is already
  in the footer (required by MailerLite — leave it in place).

THE TWO EMAIL BUTTONS
  Both CTAs are mailto: links to zoe@koryogroup.com with PRE-FILLED
  subject lines and a short body template, so replies are one tap and
  easy to triage in the inbox:

  1. "Send me an invite" (primary, solid indigo — appears twice)
     Subject: "Pakistan Research Trip - Send me an invite"
     Body prompts for name + number of travellers.

  2. "Request the full itinerary (PDF)" (secondary, outline style;
     also a text link inside the final indigo block)
     Subject: "Pakistan Research Trip - Full itinerary PDF please"

  A small note under the buttons says "or simply reply to this
  newsletter" as a fallback, since a few webmail users don't have a
  mail app wired up to mailto links.

  To change the recipient or wording, search the HTML for "mailto:" —
  spaces are encoded as %20, line breaks as %0A.

IMAGES — CLICK TO REPLACE IN MAILERLITE (5 slots + logo)
  Same system as previous emails: MailerLite's placeholder image, click
  each one in the editor and swap from your file manager. Logo already set.

  1. Koryo Tours logo    already in place — header
  2. Hero                520 wide — suggested: Kalasha women in festival dress
  3. Part One left       250 wide — suggested: Mohenjo-daro ruins
  4. Part One right      250 wide — suggested: Wazir Khan Mosque, Lahore
  5. Part Two left       250 wide — suggested: Chilam Joshi dancing
  6. Part Two right      250 wide — suggested: Takht-i-Bahi monastery

TRIP FACTS USED
  Southern & North West Pakistan + Kalash Festival — Research Trip
  3–18 May 2027 · 16 days / 15 nights · 4–8 travellers only
  $4,100 USD, single supplement $650 (framed as a research-trip price /
  discount vs. the future regular programme)
  Research trip framing: "What's a research trip?" indigo panel near the
  top — more adventure, flexibility, possible first-time tour leader,
  discounted price, feedback shapes the future tour.
  Caveat included: 2027 Chilam Joshi schedule is community-led and not
  yet formally confirmed; valley/timing may shift.

DESIGN
  ~75% white, ~20% indigo (#333A8C — the indigo from the Koryo stripe
  set: VIP tag, date band, both panels, buttons, final CTA block), with
  the remaining Koryo stripe colours (red, teal, orange, green, yellow)
  in the stripe bars, divider and bullet dots. Yellow appears only as a
  stripe colour here — indigo is the lead. Circular Std headings with
  Karla body (Karla via Google Fonts; Circular Std falls back through
  the stack unless you add your licensed @font-face). Dark mode
  (prefers-color-scheme + Outlook.com [data-ogsc]) and mobile
  single-column under 620px, matching the Yemen emails.

SUGGESTED SUBJECT LINES
  - VIP invite: our Pakistan research trip (4–8 places only)
  - Pioneers wanted: Pakistan & the Kalash Festival, May 2027
  Preheader is built in.
