KORYO TOURS — VIP NEWSLETTER: NEPAL CULTURE & HERITAGE DISCOVERY
=================================================================

FILE
  koryo-vip-nepal.html — the full email, ready to paste into MailerLite's
  Custom HTML editor. The {$unsubscribe} link is already in the footer
  (required by MailerLite — leave it in place).

LINKS TO CHECK / SWAP (the site was unreachable from where this was
built, so all tour links currently point to the Nepal landing page)
  1. Main CTA buttons (x2): https://koryogroup.com/tours/nepal
     → swap for the new Culture & Heritage tour's direct page URL
       once it's live (search the HTML for the URL — 5 occurrences
       incl. footer + "Also in Nepal" box).
  2. "Also in Nepal" box: the "Nepal & Bhutan combo" and "solo Nepal
     trip" text links → swap each for its direct tour page URL.

VIP DISCOUNT WORDING
  The email promises "$100 off as a VIP" (badge in the teal date band,
  the note under the first button: "Book as a VIP and we'll apply your
  $100 discount — you're on the list", and the final CTA headline).
  If the discount is claimed via a promo code or a hidden VIP booking
  link instead, adjust the note under the first button accordingly.

IMAGES — CLICK TO REPLACE IN MAILERLITE (5 slots + logo)
  Same system as previous emails: MailerLite's placeholder image — click
  each one in the editor and swap from your file manager. Logo already set.

  1. Koryo Tours logo    already in place — header
  2. Hero                520 wide — suggested: Boudhanath Stupa
  3. Icons left          250 wide — suggested: Everest from the flight
  4. Icons right         250 wide — suggested: Bhaktapur Durbar Square
  5. Culture left        250 wide — suggested: momo cooking class
  6. Culture right       250 wide — suggested: Namobuddha Monastery

TRIP FACTS USED
  Nepal Culture & Heritage Discovery Tour — 7 days / 6 nights
  Kathmandu · Dhulikhel · Namobuddha · Panauti · Bhaktapur · Khokana ·
  Bungmati · Patan
  Dates: not yet set in the itinerary — shown as "Dates announced soon"
  Framing: normal full tour (NOT a research trip), announced to VIPs
  before public promotion; VIPs get first priority + $100 discount.
  Focus: cultural adventure — "The icons" section (UNESCO sites, Everest
  flight, Kumari, Durbar Squares, accessible Namobuddha hike) and
  "Get stuck in" section (monastery night, momo cooking class, pottery
  class, school volunteering + community camp, Newar villages, sound
  bath, Tibetan neighbourhood).

DESIGN
  ~75% white, ~20% teal (#3BB8A8 — the teal from the Koryo stripe set:
  VIP tag, date band, panels, buttons, final CTA block; darker #23887C
  for teal text on white so it passes contrast), with the remaining
  Koryo stripe colours (red, orange, indigo, green, yellow) in the
  stripe bars, divider and bullet dots. Circular Std headings with
  Karla body (Karla via Google Fonts; Circular Std falls back through
  the stack unless you add your licensed @font-face). Dark mode
  (prefers-color-scheme + Outlook.com [data-ogsc]) and mobile
  single-column under 620px, matching the other emails.

SUGGESTED SUBJECT LINES
  - VIP first: our new Nepal cultural adventure ($100 off for you)
  - Nepal beyond the trek — VIPs book first
  Preheader is built in.
